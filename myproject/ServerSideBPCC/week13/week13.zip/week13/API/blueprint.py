from flask import Flask, Blueprint, jsonify, current_app
from flask_httpauth import HTTPBasicAuth, HTTPTokenAuth
from itsdangerous import TimedJSONWebSignatureSerializer as Serializer
from models import birds
from flask_restful import Api,Resource,url_for

app = Flask(__name__)
api_bp= Blueprint('api',__name__)
api = Api(api_bp)

class apiv1(Resource):
    def get(self, id):
        return {'bird':'Hello!'}

api.add_resource(apiv1, '/birds/apiv1/token')
app.register_blueprint(api_bp)