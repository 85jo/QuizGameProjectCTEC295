from flask import Flask, render_template, request, flash
from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField
from wtforms.validators import DataRequired
from flask_bootstrap import Bootstrap
import os
from flask_sqlalchemy import SQLAlchemy

basedir = os.path.abspath(os.path.dirname(__file__))

app = Flask(__name__)
bootstrap = Bootstrap(app)
app.config['SQLALCHEMY_DATABASE_URI'] =\
    'sqlite:////' + os.path.join(basedir, 'data.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

app.config['SECRET_KEY']= '0FCcnjjcNW94An7YUIcv'

class NameForm(FlaskForm):
    Firstname = StringField('Houesehold members First name?', validators=[DataRequired()])
    Lastname = StringField('Houesehold members Last name?', validators=[DataRequired()])
    submit = SubmitField('Submit')

class ChoreForm(FlaskForm):
    chore = StringField('Enter a new chore?', validators=[DataRequired()])
    submit = SubmitField('Submit')

class ChoreFormMember(FlaskForm):
    choreAdd = StringField('Add chore to current member.', validators=[DataRequired()])
    submit = SubmitField('Submit')
##User Db Model
class User(db.Model):
    __tablename__ = 'users'

    id = db.Column(db.Integer, primary_key=True)
    dbname = db.Column(db.String(64))
    dbMemberChore= db.relationship('Chore', backref='user', uselist=False)

    def __init__(self,dbname):
        self.dbname = dbname

    def __repr__(self):
        return f'<User {self.dbname}>'

##Chore Db Model
class Chore(db.Model):
    __tablename__ = 'chores'

    id = db.Column(db.Integer, primary_key=True)
    dbchore = db.Column(db.String(64))
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'))

    def __init__(self,dbchore,user_id):
        self.dbchore = dbchore
        self.user_id = user_id
## index route
@app.route('/', methods=['get', 'post'])
def index():
## Form instance and querying data
    form = NameForm()
    choreform = ChoreForm()
    name = None
    users = User.query.all()
    chores = None
    chores= Chore.query.all()
##form Validation member
    if form.validate_on_submit():
        dbname = request.form['Firstname']+" "+request.form['Lastname']
        record = User(dbname)
        db.session.add(record)
        db.session.commit()

        name = request.form['Firstname']
        form = NameForm( formdata = None )
        flash("Member added successfully!")
        users = User.query.all()

    return render_template('Chores.html',choreform=choreform, form=form, name=name, users=users, chores=chores)

##Members route
@app.route('/Member/<id>', methods=['get', 'post'])
##Takes in Member id
def Members(id):
    choreformMember = ChoreFormMember()
    if choreformMember.validate_on_submit():
        dbchoreadd = request.form['choreAdd']
        member = User.query.filter(User.id==id).first()
        exist  = Chore.query.filter(Chore.user_id==id).first()
        ##Validate if a chore exist for member
        if exist==None:
            print("Chore added "+dbchoreadd)
            recordChore = Chore(dbchoreadd,id)
            db.session.add(recordChore)
            db.session.commit()
            flash("Chore added successfully!")
        ##check if new chore from form is current chore or a new chore. replace with new chore
        elif dbchoreadd != member.dbMemberChore.dbchore or dbchoreadd == member.dbMemberChore.dbchore:
            print("Chore not added "+dbchoreadd)
            recordChore = Chore.query.filter(Chore.user_id==member.id).first()
            db.session.delete(recordChore)
            db.session.commit()

            print("Chore added "+dbchoreadd)
            recordChore = Chore(dbchoreadd,id)
            db.session.add(recordChore)
            db.session.commit()
            flash("Chore added successfully!")
        else:
            print("Chore not added "+dbchoreadd)
            recordChore = Chore.query.filter(Chore.user_id==member.id).first()
            db.session.delete(recordChore)
            db.session.commit()
    ## check if id is in the database from id decerator in route address, if not throw 404 error 
    try:
        name = User.query.get(id).dbname
    except:
        return render_template('404.html'),404
    users = None
    users = User.query.all()
    chores = None
    chores= Chore.query.all()
    
    
    return render_template('Member.html', name=name, users=users, chores=chores, choreformMember=choreformMember)
#404 error page
@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html'),404

if __name__ == "__main__":
    db.create_all()
    db.session.commit()
    app.run(debug=True)